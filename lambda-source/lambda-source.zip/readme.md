# Pardot Form Handler Lambda

```bash
yarn install
```